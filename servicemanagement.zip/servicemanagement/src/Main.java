import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Main extends JFrame {
    // GUI components
    private final JTextField usernameField;
    private final JPasswordField passwordField;
    private Connection connection;

    public Main() {
        // Set up the GUI
        setTitle("Service Management System");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));

        JLabel usernameLabel = new JLabel("Username:");
        JLabel passwordLabel = new JLabel("Password:");
        usernameField = new JTextField();
        passwordField = new JPasswordField();
        JButton loginButton = new JButton("Login");
        JButton createAccountButton = new JButton("Create Account");

        // Add components to the frame
        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);
        add(createAccountButton);

        // Connect to the database
        try {
            // Establish database connection
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/servicemanagement", "root", "alluri1693");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // Event listeners
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        createAccountButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createAccountWindow();
            }
        });

        setVisible(true);
    }

    // Method to handle login
    protected void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        try {
            // Check in user table
            String userQuery = "SELECT * FROM user WHERE username=? AND password=?";
            PreparedStatement userStatement = connection.prepareStatement(userQuery);
            userStatement.setString(1, username);
            userStatement.setString(2, password);
            ResultSet userResultSet = userStatement.executeQuery();

            // Check in serviceprovider table
            String serviceProviderQuery = "SELECT * FROM serviceprovider WHERE username=? AND password=?";
            PreparedStatement serviceProviderStatement = connection.prepareStatement(serviceProviderQuery);
            serviceProviderStatement.setString(1, username);
            serviceProviderStatement.setString(2, password);
            ResultSet serviceProviderResultSet = serviceProviderStatement.executeQuery();

            if (userResultSet.next()) {
                // Retrieve user data from the result set
                String name = userResultSet.getString("name");
                String surname = userResultSet.getString("surname");
                String email = userResultSet.getString("email");

                // Display user information
                JOptionPane.showMessageDialog(this, "User Login successful\nName: " + name + "\nSurname: " + surname + "\nEmail: " + email);

                // Open user dashboard
                userDashboard(username); // Pass 'username' to the user dashboard method
            } else if (serviceProviderResultSet.next()) {
                // Retrieve service provider data from the result set
                String name = serviceProviderResultSet.getString("name");
                String surname = serviceProviderResultSet.getString("surname");
                String email = serviceProviderResultSet.getString("email");

                // Display service provider information
                JOptionPane.showMessageDialog(this, "Service Provider Login successful\nName: " + name + "\nSurname: " + surname + "\nEmail: " + email);

                // Open service provider dashboard
                serviceProviderDashboard(username, name, email);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Method to create the account window
    private void createAccountWindow() {
        JFrame accountFrame = new JFrame("Create Account");
        accountFrame.setSize(350, 250);
        accountFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        accountFrame.setLayout(new GridLayout(8, 2));

        JLabel typeLabel = new JLabel("Account Type:");
        JRadioButton userRadioButton = new JRadioButton("User");
        JRadioButton serviceProviderRadioButton = new JRadioButton("Service Provider");
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(userRadioButton);
        buttonGroup.add(serviceProviderRadioButton);

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();
        JLabel surnameLabel = new JLabel("Surname:");
        JTextField surnameField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();
        JLabel usernameLabel = new JLabel("Username:");
        JTextField newUsernameField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField newPasswordField = new JPasswordField();
        JButton createButton = new JButton("Create");

        // Add components to the account frame
        accountFrame.add(typeLabel);
        accountFrame.add(userRadioButton);
        accountFrame.add(new JLabel()); // Empty label for spacing
        accountFrame.add(serviceProviderRadioButton);
        accountFrame.add(nameLabel);
        accountFrame.add(nameField);
        accountFrame.add(surnameLabel);
        accountFrame.add(surnameField);
        accountFrame.add(emailLabel);
        accountFrame.add(emailField);
        accountFrame.add(usernameLabel);
        accountFrame.add(newUsernameField);
        accountFrame.add(passwordLabel);
        accountFrame.add(newPasswordField);
        accountFrame.add(new JLabel()); // Empty label for spacing
        accountFrame.add(createButton);

        createButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Retrieve input values
                String name = nameField.getText();
                String surname = surnameField.getText();
                String email = emailField.getText();
                String newUsername = newUsernameField.getText();
                String newPassword = new String(newPasswordField.getPassword());
                String accountType = userRadioButton.isSelected() ? "User" : "Service Provider";

                // Determine which table to insert data into
                String tableName = (accountType.equals("User")) ? "user" : "serviceprovider";

                // Save the new account details to the appropriate table
                try {
                    String query = "INSERT INTO " + tableName + " (name, surname, email, username, password) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, name);
                    preparedStatement.setString(2, surname);
                    preparedStatement.setString(3, email);
                    preparedStatement.setString(4, newUsername);
                    preparedStatement.setString(5, newPassword);

                    int rowsAffected = preparedStatement.executeUpdate();
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(accountFrame, "Account created successfully");
                        accountFrame.dispose(); // Close the account creation window
                    } else {
                        JOptionPane.showMessageDialog(accountFrame, "Failed to create account");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(accountFrame, "Failed to create account: " + ex.getMessage());
                }
            }
        });
        accountFrame.setVisible(true);
    }

    // Method to create the service provider dashboard
    private void serviceProviderDashboard(String serviceProviderUsername, String serviceProviderName, String serviceProviderEmail) {
        JFrame dashboardFrame = new JFrame("Service Provider Dashboard");
        dashboardFrame.setSize(500, 300);
        dashboardFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        dashboardFrame.setLayout(new BorderLayout());

        // Components for service provider details
        JPanel providerDetailsPanel = new JPanel(new GridLayout(3, 2));
        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField(serviceProviderName); // Set the name from the parameter
        nameField.setEditable(false); // Make it non-editable
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(serviceProviderEmail); // Set the email from the parameter
        emailField.setEditable(false); // Make it non-editable
        providerDetailsPanel.add(nameLabel);
        providerDetailsPanel.add(nameField);
        providerDetailsPanel.add(emailLabel);
        providerDetailsPanel.add(emailField);

        // Components for service details
        JPanel serviceDetailsPanel = new JPanel(new GridLayout(3, 2));
        JLabel serviceNameLabel = new JLabel("Service:");
        JTextField serviceNameField = new JTextField();
        JLabel hourlyRateLabel = new JLabel("Hourly Rate:");
        JTextField hourlyRateField = new JTextField();
        serviceDetailsPanel.add(serviceNameLabel);
        serviceDetailsPanel.add(serviceNameField);
        serviceDetailsPanel.add(hourlyRateLabel);
        serviceDetailsPanel.add(hourlyRateField);

        // Button to add service
        JButton addServiceButton = new JButton("Add Service");

        // Add components to the dashboard frame
        dashboardFrame.add(providerDetailsPanel, BorderLayout.NORTH);
        dashboardFrame.add(serviceDetailsPanel, BorderLayout.CENTER);
        dashboardFrame.add(addServiceButton, BorderLayout.SOUTH);

        // Event listener for adding a service
        addServiceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String serviceName = serviceNameField.getText();
                String hourlyRateStr = hourlyRateField.getText();

                // Validate input
                if (serviceName.isEmpty() || hourlyRateStr.isEmpty()) {
                    JOptionPane.showMessageDialog(dashboardFrame, "Please enter service name and hourly rate.");
                    return;
                }

                try {
                    double hourlyRate = Double.parseDouble(hourlyRateStr);

                    // Insert service into database
                    String insertServiceQuery = "INSERT INTO services (name, email, service, hourlyrate) VALUES (?, ?, ?, ?)";
                    PreparedStatement insertServiceStatement = connection.prepareStatement(insertServiceQuery);
                    insertServiceStatement.setString(1, serviceProviderName); // Use the parameter
                    insertServiceStatement.setString(2, serviceProviderEmail); // Use the parameter
                    insertServiceStatement.setString(3, serviceName);
                    insertServiceStatement.setDouble(4, hourlyRate);
                    int rowsAffected = insertServiceStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(dashboardFrame, "Service added successfully.");
                    } else {
                        JOptionPane.showMessageDialog(dashboardFrame, "Failed to add service.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(dashboardFrame, "Invalid hourly rate format.");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(dashboardFrame, "Error: " + ex.getMessage());
                }
            }
        });

        // Display the dashboard
        dashboardFrame.setVisible(true);
    }

    // Method to create the user dashboard
    private void userDashboard(String username) {
        JFrame userFrame = new JFrame("User Dashboard");
        userFrame.setSize(600, 400);
        userFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        userFrame.setLayout(new BorderLayout());

        // Components for search
        JLabel searchLabel = new JLabel("Search Services:");
        JTextField searchField = new JTextField();
        JButton searchButton = new JButton("Search");

        // Component for displaying search results
        JTextArea searchResultsTextArea = new JTextArea();
        searchResultsTextArea.setEditable(false);
        JScrollPane searchResultsScrollPane = new JScrollPane(searchResultsTextArea);

        // Fetch available services from the database
        searchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String searchTerm = searchField.getText().trim();

                if (!searchTerm.isEmpty()) {
                    try {
                        String query = "SELECT * FROM services WHERE service LIKE ?";
                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.setString(1, "%" + searchTerm + "%");
                        ResultSet resultSet = preparedStatement.executeQuery();

                        searchResultsTextArea.setText(""); // Clear previous search results

                        while (resultSet.next()) {
                            String serviceName = resultSet.getString("service");
                            double hourlyRate = resultSet.getDouble("hourlyrate");

                            searchResultsTextArea.append("Service: " + serviceName + "\n");
                            searchResultsTextArea.append("Hourly Rate: " + hourlyRate + "\n\n");
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(userFrame, "Failed to search services: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(userFrame, "Please enter a search term.");
                }
            }
        });

        // Button to request an appointment
        JButton requestAppointmentButton = new JButton("Request Appointment");

        // Button to manage appointments
        JButton manageAppointmentsButton = new JButton("Manage Appointments");

        // Button to logout
        JButton logoutButton = new JButton("Logout");

        // Add components to the user dashboard frame
        JPanel searchPanel = new JPanel(new BorderLayout());
        searchPanel.add(searchLabel, BorderLayout.WEST);
        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(searchButton, BorderLayout.EAST);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3));
        buttonPanel.add(requestAppointmentButton);
        buttonPanel.add(manageAppointmentsButton);
        buttonPanel.add(logoutButton);

        userFrame.add(searchPanel, BorderLayout.NORTH);
        userFrame.add(searchResultsScrollPane, BorderLayout.CENTER);
        userFrame.add(buttonPanel, BorderLayout.SOUTH);

        // Event listener for requesting an appointment
        requestAppointmentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get selected service from search results
                String selectedService = searchResultsTextArea.getSelectedText();
                if (selectedService == null || selectedService.isEmpty()) {
                    JOptionPane.showMessageDialog(userFrame, "Please select a service from the search results.");
                } else {
                    // Get date and time from the user
                    String selectedDate = JOptionPane.showInputDialog(userFrame, "Enter Date (YYYY-MM-DD):");
                    String selectedTime = JOptionPane.showInputDialog(userFrame, "Enter Time (HH:MM):");
                    String address = JOptionPane.showInputDialog(userFrame,"Enter Your Address:");

                    if (selectedDate != null && selectedTime != null && address != null) {
                        // Perform action to request an appointment with date, time, and address
                        String appointmentDateTime = selectedDate + " " + selectedTime;
                        bookAppointment(username, selectedService, appointmentDateTime, address);
                    }
                }
            }
        });

        // Event listener for managing appointments
        manageAppointmentsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform action to manage appointments
                manageAppointments(username);
            }
        });

        // Event listener for logout
        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform logout action
                int option = JOptionPane.showConfirmDialog(userFrame, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    userFrame.dispose();
                    // Code to handle logout goes here
                }
            }
        });

        // Display the user dashboard
        userFrame.setVisible(true);
    }

    // Method to manage user appointments
    private void manageAppointments(String username) {
        JFrame appointmentFrame = new JFrame("Manage Appointments");
        appointmentFrame.setSize(500, 300);
        appointmentFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        appointmentFrame.setLayout(new BorderLayout());

        // Fetch user appointments from the database
        try {
            String query = "SELECT * FROM appointments WHERE username=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            // Create table model
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.addColumn("Service");
            tableModel.addColumn("Appointment DateTime");

            // Add rows to the table model
            while (resultSet.next()) {
                String serviceName = resultSet.getString("service");
                String appointmentDateTime = resultSet.getString("appointmentdatetime");

                tableModel.addRow(new String[]{serviceName, appointmentDateTime});
            }

            // Create table
            JTable appointmentTable = new JTable(tableModel);

            // Add table to scroll pane
            JScrollPane scrollPane = new JScrollPane(appointmentTable);

            // Add scroll pane to frame
            appointmentFrame.add(scrollPane, BorderLayout.CENTER);

            // Buttons for canceling and rescheduling appointments
            JPanel buttonPanel = new JPanel(new GridLayout(1, 2));
            JButton cancelButton = new JButton("Cancel Appointment");
            JButton rescheduleButton = new JButton("Reschedule Appointment");
            buttonPanel.add(cancelButton);
            buttonPanel.add(rescheduleButton);
            appointmentFrame.add(buttonPanel, BorderLayout.SOUTH);

            // Event listener for canceling an appointment
            cancelButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Get selected appointment
                    int selectedRow = appointmentTable.getSelectedRow();
                    if (selectedRow == -1) {
                        JOptionPane.showMessageDialog(appointmentFrame, "Please select an appointment to cancel.");
                    } else {
                        String serviceName = (String) appointmentTable.getValueAt(selectedRow, 0);
                        String appointmentDateTime = (String) appointmentTable.getValueAt(selectedRow, 1);
                        cancelAppointment(username, serviceName, appointmentDateTime);
                        appointmentFrame.dispose();
                    }
                }
            });

            // Event listener for rescheduling an appointment
            rescheduleButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Get selected appointment
                    int selectedRow = appointmentTable.getSelectedRow();
                    if (selectedRow == -1) {
                        JOptionPane.showMessageDialog(appointmentFrame, "Please select an appointment to reschedule.");
                    } else {
                        String serviceName = (String) appointmentTable.getValueAt(selectedRow, 0);
                        String appointmentDateTime = (String) appointmentTable.getValueAt(selectedRow, 1);
                        String newDateTime = JOptionPane.showInputDialog(appointmentFrame, "Enter new date and time (YYYY-MM-DD HH:MM):");
                        if (newDateTime != null) {
                            rescheduleAppointment(username, serviceName, appointmentDateTime, newDateTime);
                            appointmentFrame.dispose();
                        }
                    }
                }
            });
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(appointmentFrame, "Failed to fetch appointments: " + ex.getMessage());
        }

        // Display the appointment management frame
        appointmentFrame.setVisible(true);
    }

    // Method to book an appointment
    private void bookAppointment(String username, String serviceName, String appointmentDateTime, String address) {
        try {
            String query = "INSERT INTO appointments (username, service, appointmentdatetime, address) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, serviceName);
            preparedStatement.setString(3, appointmentDateTime);
            preparedStatement.setString(4, address);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Appointment booked successfully");
            } else {
                JOptionPane.showMessageDialog(null, "Failed to book appointment");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to book appointment: " + ex.getMessage());
        }
    }

    // Method to cancel an appointment
    private void cancelAppointment(String username, String serviceName, String appointmentDateTime) {
        try {
            String query = "DELETE FROM appointments WHERE username=? AND service=? AND appointmentdatetime=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, serviceName);
            preparedStatement.setString(3, appointmentDateTime);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Appointment canceled successfully");
            } else {
                JOptionPane.showMessageDialog(null, "Failed to cancel appointment");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to cancel appointment: " + ex.getMessage());
        }
    }

    // Method to reschedule an appointment
    private void rescheduleAppointment(String username, String serviceName, String oldDateTime, String newDateTime) {
        try {
            String query = "UPDATE appointments SET appointmentdatetime=? WHERE username=? AND service=? AND appointmentdatetime=?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newDateTime);
            preparedStatement.setString(2, username);
            preparedStatement.setString(3, serviceName);
            preparedStatement.setString(4, oldDateTime);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Appointment rescheduled successfully");
            } else {
                JOptionPane.showMessageDialog(null, "Failed to reschedule appointment");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to reschedule appointment: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        // Run the application
        SwingUtilities.invokeLater(Main::new);
    }
}
